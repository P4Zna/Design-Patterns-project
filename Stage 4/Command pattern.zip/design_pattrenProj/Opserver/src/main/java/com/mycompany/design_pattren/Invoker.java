package com.mycompany.design_pattren;

public class Invoker {
    
    public void  excuteCommand(Command command){
        command.execute(); 
	} 

}
