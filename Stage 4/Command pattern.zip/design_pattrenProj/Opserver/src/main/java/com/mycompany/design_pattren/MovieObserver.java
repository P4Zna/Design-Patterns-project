package com.mycompany.design_pattren;

/**
 *
 * @author رغد
 */
public interface MovieObserver {
    void update(Movie movie);
}
