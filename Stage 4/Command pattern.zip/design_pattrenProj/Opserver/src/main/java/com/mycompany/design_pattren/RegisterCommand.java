package com.mycompany.design_pattren;

public class RegisterCommand implements Command{
    
    private Person person;
    private String name;
    private String email;
    private String password;
    private Person.Role role;


    public RegisterCommand(Person person){ 
		this.person = person;
        this.name = name;
        this.email = email;
        this.password = password;

    }

        public void execute() {
        person.createPerson(name, email, password, role);
    }

}
