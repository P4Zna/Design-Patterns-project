package com.mycompany.design_pattren;

public interface Command {
    void execute();
}
